-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-09-2017 a las 10:01:39
-- Versión del servidor: 10.1.25-MariaDB
-- Versión de PHP: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `spring`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `nombre` varchar(256) NOT NULL,
  `descripcion` mediumtext NOT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `items`
--

INSERT INTO `items` (`id`, `nombre`, `descripcion`, `url`) VALUES
(1, ' Pepitos de crema', 'Para prepararlos tendrás que freír unos panecillos especiales para perritos y luego los rebozas en en azúcar mezclado con canela. Una vez fríos, los abres y los rellenas con una generosa cantidad de crema pastelera.', 'http://azu1.facilisimo.com/ima/i/1/c/56/gr_937217_6926751_582784.jpg'),
(2, ' Tarta de manzana', 'Con una masa quebrada cubres la base de un molde. Lo llenas con la crema pastelera y lo cubres con láminas de manzana en crudo y un poco de azúcar. Se hornea y luego se decora con unas cucharadas de mermelada de melocotón o albaricoque.', 'http://azu1.facilisimo.com/ima/i/1/c/56/gr_937217_6926764_108838.jpg'),
(3, 'Bandeja de pasteles', 'Alaska de fresa, barquita de frambuesa, bocadito de nata, bomba de naranja, canutillo de crema, capuchina, disco de chocolate, eclair de caramelo.', 'http://www.pasteleria-mallorca.com/ka/apps/mallorca/assets/products/pasteles.jpg'),
(4, 'TARTA TRES CHOCOLATES', 'Bizcocho de chocolate con mousse de chocolate blanco, chocolate de leche y chocolate negro con un baño de chocolate negro brillante.', 'http://www.pasteleria-mallorca.com/ka/apps/mallorca/assets/products/10601.jpg'),
(5, 'LOCAS', 'Elaboradas con hojaldre, crema pastelera, un glaseado de yema y decorada con guindas', 'http://2.bp.blogspot.com/-8Ok9kMATsPQ/VqDB6hHb9XI/AAAAAAAAa8s/wY_ltyDoAjk/s1600/Torta-loca-malague%25C3%25B1a-portada-1.jpg'),
(6, 'Tarta Mousse', 'Tarta mousse de limón y arándanos con chocolate', 'https://4.bp.blogspot.com/-lJ7pmwhQBZo/WWSwrk2S1rI/AAAAAAAA0kA/3Hc0JhwFuBU2cXchwmLDypU4zIKdCDX8gCLcBGAs/s1600/Tarta-mousse-de-lim%25C3%25B3n-y-ar%25C3%25A1ndanos.jpg'),
(7, 'Flan', 'Flan de coco y condensada casero', 'https://4.bp.blogspot.com/-pcI9Dz-2RwU/WDwrmaSnWII/AAAAAAAAn4M/OcScKxlqbIoksomD5DK9t7SHnTtJifd3ACLcB/s1600/Flan-de-coco-con-condensada-casero.jpg'),
(8, 'Tarta de queso', 'Tarta de queso al horno esponjosa', 'http://3.bp.blogspot.com/-LicnOkDvQLQ/Vf3gRH91_QI/AAAAAAAAS_4/Yomvt16E9Ss/s1600/Tarta-de-Queso-Esponjosa-portada-1.jpg');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
